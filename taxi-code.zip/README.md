## Steps

1. Clone the repository.
2. Run "npm install".
3. Run "npm run start".

## How to use

1. Input the details like name, mobile number, pick up date, pick up time, pick up place, dropping place, vehicle class ,additional requirments.
2. A modal will appear that will contain your details.
